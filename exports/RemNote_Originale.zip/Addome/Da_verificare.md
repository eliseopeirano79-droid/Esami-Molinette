# Addome — Domande da verificare

Queste 4 domande NON sono state convertite automaticamente in quiz RemNote: alcune hanno più risposte corrette, una presenta due marcature dubbie e una non ha alcuna risposta identificata. Sono conservate integralmente nella banca dati JSON e funzionano, dove verificabili, nella app di prova.

## Nefrologia — Glomerulonefriti
- Quale di queste glomerulonefriti non si associa a ipocomplementemia acquisita? (due risposte esatte)
  - A) da crioglobulinemia mista
  - B) proliferativa diffusa lupica
  - C) a lesioni minime [EVIDENZIATA nel mazzo]
  - D) membrano proliferativa
  - E) acuta postinfettiva
  - F) membranosa idiopatica [EVIDENZIATA nel mazzo]
  - ID originale: 1656597466206

## Nefrologia — Glomerulonefriti
- Quale di queste glomerulopatie non si associa a ipocomplementemia acquisita (barrare anche più di una voce)?
  - A) la GNF in corso di crioglobulinemia mista
  - B) la proliferativa diffusa lupica
  - C) la glomerulosclerosi diabetica [EVIDENZIATA nel mazzo]
  - D) la GNF acuta post infettiva
  - E) il danno glomerulare da amiloidosi [EVIDENZIATA nel mazzo]
  - F) la GNF membrano proliferativa
  - G) la glomerulo nefrite membranosa idiopatica [EVIDENZIATA nel mazzo]
  - ID originale: 1656598038746

## Nefrologia — Pielonefrite
- La pielonefrite è una nefropatia interstiziale causata direttamente da:
  - A) Agenti infettivi [EVIDENZIATA nel mazzo]
  - B) Assunzione prolungata nel tempo di analgesici
  - C) Diabete mellito di tipo 2
  - D) Assunzione abituale di antiinfiammatori non steroidei
  - E) Reflusso vescica-ureterale congenito [EVIDENZIATA nel mazzo]
  - ⚠️ Evidenziazioni associate al simbolo (?) nella risposta originale.
  - ID originale: 1679061284209

## Nefrologia — Malattia renale cronica
- L'iperparatiroidismo secondario è una condizione clinica comune:
  - A) nei pazienti con insufficienza renale cronica dal 2-3 stadio in avanti
  - B) unicamente nei pazienti in emodialisi e dialisi peritoneale
  - C) unicamente nei pazienti con insufficienza renale cronica 5 stadio, in emodialisi e dialisi peritoneale
  - D) unicamente nei pazienti in dialisi peritoneale
  - E) unicamente nei pazienti in emodialisi
  - ⚠️ Nessuna soluzione indicata nel mazzo.
  - ID originale: 1721748411556
